public class BatTest {
    public static void main(String[] args) {
        Bat b=new Bat();
        b.terrorizeTown();
        b.terrorizeTown();
        b.terrorizeTown();
        b.eatHumans();
        b.eatHumans();
        b.fly();
        b.fly();
        b.displayEnergy();
    }
}
