function msg(){  
 alert("This is the date template!");  
}

function msg2(){
	alert("this is the time template!");
}  