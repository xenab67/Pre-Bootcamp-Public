package com.codingdojo.dojoSurveyTwo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DojoSurveyTwoApplicationTests {

	@Test
	void contextLoads() {
	}

}
