package com.codingdojo.views;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ViewsApplicationTests {

	@Test
	void contextLoads() {
	}

}
