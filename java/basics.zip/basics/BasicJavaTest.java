public class BasicJavaTest {
    public static void main (String[] args) {
        BasicJava basics = new BasicJava();
        int[] nums = {23,234,2345,-23,42};
		// basics.LoopArray(nums);
		// System.out.println(basics.GetArraySum(nums));
        // basics.OneTo255();
        // basics.PrintOdds();
        // basics.PrintSum();
        // System.out.println(basics.FindMax(nums));
        // System.out.println(basics.OddArray());
        }
}