print("Hello World!")

name = "Xena"
print ("Hello",name,"!")
print ("Hello " + name + "!")

name= 67
print ("Hello", name,"!")
# print ("Hello " +name +"!")
print ("Hello " + str(name) +"!")

fave_food1 = "pizza"
fave_food2 = "burgers"
print ("I love to eat {} and {}.".format(fave_food1, fave_food2))
print (f"I love to eat {fave_food1} and {fave_food2}.")